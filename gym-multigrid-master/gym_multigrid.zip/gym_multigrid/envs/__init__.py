from gym_multigrid.envs.collect_game import *
from gym_multigrid.envs.soccer_game import SoccerGame4HEnv10x15N2